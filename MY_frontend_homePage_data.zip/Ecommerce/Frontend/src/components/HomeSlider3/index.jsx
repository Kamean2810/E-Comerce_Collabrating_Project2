import React, { useRef } from "react";

const products = [
  { id: 1, name: "The North Coat", price: "$491.99", image: "/item-12.jpg" },
  { id: 2, name: "Gucci Duffle Bag", price: "$899.99", image: "/item-13.jpg" },
  { id: 3, name: "RGB Liquid CPU Cooler", price: "$59.99", image: "/item-14.jpg" },
  { id: 4, name: "Small Book Self", price: "$39.99", image: "/item-15.jpg" },
  { id: 5, name: "Home Decuration Piece", price: "$12.99", image: "/item-16.jpg" },
  { id: 6, name: "MakeUp Box for Women's", price: "$81.99", image: "/item-17.jpg" },
  { id: 7, name: "Orignal Labubu Doll", price: "$85.99", image: "/item-18.jpg" },
  { id: 8, name: "Men's Office Shose", price: "$17.99", image: "/item-19.jpg" },
];

const HomeSlider3 = () => {
  const scrollRef = useRef(null);

  const scroll = (direction) => {
    if (scrollRef.current) {
      const scrollAmount = direction === "left" ? -300 : 300;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  return (
      <div className="py-10 bg-white border-t border-gray-300">
        <div className="container mx-auto px-4">
          {/* Title + Arrows */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-[55px] font-bold">Best Salling Products</h2>
            <div className="space-x-4">
              <button
                onClick={() => scroll("left")}
                className="w-12 h-12 text-2xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
              >
                &#8592;
              </button>
              <button
                onClick={() => scroll("right")}
                className="w-12 h-12 text-2xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
              >
                &#8594;
              </button>
            </div>
          </div>

          {/* Product Slider */}
          <div
            ref={scrollRef}
            className="flex space-x-6 overflow-x-auto pb-4 scrollbar-hide"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="min-w-[200px] w-64 bg-gray-100 rounded-lg shadow-md p-4"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h3 className="text-lg font-semibold">{product.name}</h3>
                <p className="text-red-500 font-bold text-xl">{product.price}</p>
              </div>
            ))}
          </div>

          {/* View All Products Button */}
          <div className="text-center mt-8">
            <button className="bg-black text-white px-6 py-3 rounded-full text-lg hover:bg-gray-800">
              View All Products
            </button>
          </div>

          {/* Horizontal Line */}
          <hr className="mt-10 border-t-2 border-gray-300" />
        </div>
      </div>
  );
};

export default HomeSlider3;
