import React, { useState } from "react";
import { Link } from "react-router-dom";  // Import Link
import { FiSearch, FiHeart, FiShoppingCart } from "react-icons/fi";

const Header = () => {
  const [language, setLanguage] = useState("en");

  const handleChange = (e) => {
    setLanguage(e.target.value);
  };

  return (
    <header>
      {/* Top Strip */}
      <div className="top-strip py-3 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            {/* Centered Message */}
            <div className="flex-1 text-center">
              <p className="text-[20px]">
                Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! &nbsp;
                <b>
                  <u>ShopNow</u>
                </b>
              </p>
            </div>

            {/* Language Selector */}
            <div className="ml-auto">
              <select
                value={language}
                onChange={handleChange}
                className="bg-black text-white px-2 py-1 rounded text-sm"
              >
                <option value="en">English</option>
                <option value="ur">اردو</option>
                <option value="hi">हिन्दी</option>
                <option value="fr">Français</option>
                <option value="ar">العربية</option>
                <option value="zh">中文</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="header py-2 bg-white text-black shadow-md">
        <div className="container mx-auto px-4 flex items-center justify-between">

          {/* Left - Logo */}
          <div className="flex-shrink-0">
            <p className="text-[55px] font-bold">Exclusive</p>
          </div>

          {/* Center - Nav Links */}
          <div className="flex-grow flex justify-center">
            <div className="flex space-x-8 text-lg">
              <Link to="/" className="hover:text-gray-600 text-[25px] font-bold">Home</Link>
              <Link to="/contact" className="hover:text-gray-600 text-[25px] font-bold">Contact</Link>
              <Link to="/about" className="hover:text-gray-600 text-[25px] font-bold">About Us</Link>
              <Link to="/signin" className="hover:text-gray-600 text-[25px] font-bold">Sign In</Link>
            </div>
          </div>

          {/* Right - Search & Icons */}
          <div className="flex-shrink-0 flex items-center space-x-4">
            {/* Search Bar */}
            <div className="hidden md:flex items-center border border-gray-300 rounded-md px-3 py-1">
              <input
                type="text"
                placeholder="Search"
                className="outline-none text-sm bg-transparent"
              />
              <FiSearch className="ml-2 text-gray-600" />
            </div>

            {/* Icons */}
            <FiHeart className="text-2xl hover:text-gray-600 cursor-pointer" />
            <FiShoppingCart className="text-2xl hover:text-gray-600 cursor-pointer" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
