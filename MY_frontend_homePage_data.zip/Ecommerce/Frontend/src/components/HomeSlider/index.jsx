import React, { useRef } from "react";

const products = [
  { id: 1, name: "HAVIT HV-G92 Game Pad", price: "$49.99", image: "/item-1.jpg" },
  { id: 2, name: "AK-900 Wired Keyboard", price: "$89.99", image: "/item-2.jpg" },
  { id: 3, name: "S-series Comfort Chair", price: "$59.99", image: "/item-4.jpg" },
  { id: 4, name: "Bluetooth Speaker", price: "$39.99", image: "/item-3.jpg" },
  { id: 5, name: "Gaming Chair", price: "$29.99", image: "/item-5.jpg" },
  { id: 6, name: "HVG-11 Air Buds", price: "$8.99", image: "/item-6.jpg" },
  { id: 7, name: "DELL Desktop-12hv", price: "$85.99", image: "/item-7.jpg" },
  { id: 8, name: "Wireless Mouse", price: "$7.99", image: "/item-8.jpg" },
  { id: 9, name: "NEW Model LAPTOP", price: "$910.99", image: "/item-9.jpg" },
  { id: 10, name: "FHC-987 Speaker", price: "$29.99", image: "/item-10.jpg" },
  { id: 11, name: "Connected Hub 3W", price: "$7.99", image: "/item-11.jpg" },
];

const HomeSlider = () => {
  const scrollRef = useRef(null);

  const scroll = (direction) => {
    if (scrollRef.current) {
      const scrollAmount = direction === "left" ? -300 : 300;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  return (
    <div>
      {/* Banner Section */}
      <div className="slider py-20 bg-white text-black shadow-md border-t border-gray-300">
        <div className="container mx-auto px-4 flex">
          <div className="w-1/3 pr-6 border-r border-gray-300">
            <ul className="space-y-4 text-[22px] font-medium">
              <li><a href="#" className="hover:text-gray-600">Women's Fashion &gt;</a></li>
              <li><a href="#" className="hover:text-gray-600">Men's Fashion &gt;</a></li>
              <li><a href="#" className="hover:text-gray-600">Electronics</a></li>
              <li><a href="#" className="hover:text-gray-600">Home & Lifestyle</a></li>
              <li><a href="#" className="hover:text-gray-600">Medicine</a></li>
              <li><a href="#" className="hover:text-gray-600">Sports & Outdoor</a></li>
              <li><a href="#" className="hover:text-gray-600">Baby's & Toys</a></li>
              <li><a href="#" className="hover:text-gray-600">Groceries & Pets</a></li>
              <li><a href="#" className="hover:text-gray-600">Health & Beauty</a></li>
            </ul>
          </div>
          <div className="w-2/3 pl-6">
            <img
              src="/dic_product.jpg.jpg"
              alt="Banner"
              className="w-full h-auto rounded-md"
            />
          </div>
        </div>
      </div>

      {/* Flash Sales Section */}
      <div className="py-10 bg-white border-t border-gray-300">
        <div className="container mx-auto px-4">
          {/* Title + Arrows */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-[55px] font-bold">Flash Sales</h2>
            <div className="space-x-4">
              <button
                onClick={() => scroll("left")}
                className="w-12 h-12 text-2xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
              >
                &#8592;
              </button>
              <button
                onClick={() => scroll("right")}
                className="w-12 h-12 text-2xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
              >
                &#8594;
              </button>
            </div>
          </div>

          {/* Product Slider */}
          <div
            ref={scrollRef}
            className="flex space-x-6 overflow-x-auto pb-4 scrollbar-hide"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="min-w-[200px] w-64 bg-gray-100 rounded-lg shadow-md p-4"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h3 className="text-lg font-semibold">{product.name}</h3>
                <p className="text-red-500 font-bold text-xl">{product.price}</p>
              </div>
            ))}
          </div>

          {/* View All Products Button */}
          <div className="text-center mt-8">
            <button className="bg-black text-white px-6 py-3 rounded-full text-lg hover:bg-gray-800">
              View All Products
            </button>
          </div>

          {/* Horizontal Line */}
          <hr className="mt-10 border-t-2 border-gray-300" />
        </div>
      </div>
    </div>
  );
};

export default HomeSlider;
