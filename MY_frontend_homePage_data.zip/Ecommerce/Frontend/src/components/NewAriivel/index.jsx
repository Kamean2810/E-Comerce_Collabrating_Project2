import React from "react";

const products = [
  { id: 1, name: "The North Coat", image: "/item-29.jpg" },
  { id: 2, name: "Gucci Duffle Bag", image: "/item-30.jpg" },
  { id: 3, name: "RGB Liquid CPU Cooler", image: "/item-31.jpg" },
  { id: 4, name: "Small Book Shelf", image: "/item-32.jpg" },
];

const NewArrival = () => {
  return (
    <div className="py-16 bg-white px-4 md:px-16">
      <h2 className="text-[40px] md:text-[55px] font-bold mb-10">
        NEW Arrivel
      </h2>

      {/* Fixed height for layout */}
      <div className="flex flex-col md:flex-row gap-6 h-[1000px]">
        {/* Left large image */}
        <div className="relative w-full md:w-1/2 h-full flex flex-col">
          <div className="relative flex-1">
            <img
              src={products[0].image}
              alt={products[0].name}
              className="w-full h-full object-cover rounded-lg shadow-lg"
            />
            <div className="absolute bottom-4 left-4 text-white z-10">
              <h3 className="text-2xl font-semibold">{products[0].name}</h3>
              <a
                href="#"
                className="text-white underline text-sm font-medium mt-1 inline-block"
              >
                Shop Now
              </a>
            </div>
            <div className="absolute inset-0 bg-black/30 rounded-lg" />
          </div>
        </div>

        {/* Right side stacked */}
        <div className="w-full md:w-1/2 flex flex-col gap-6 h-full">
          {/* Top right image */}
          <div className="relative flex-1">
            <img
              src={products[1].image}
              alt={products[1].name}
              className="w-full h-full object-cover rounded-lg shadow-lg"
            />
            <div className="absolute bottom-4 left-4 text-white z-10">
              <h3 className="text-lg font-semibold">{products[1].name}</h3>
              <a
                href="#"
                className="text-white underline text-sm font-medium mt-1 inline-block"
              >
                Shop Now
              </a>
            </div>
            <div className="absolute inset-0 bg-black/30 rounded-lg" />
          </div>

          {/* Bottom row */}
          <div className="flex gap-6 flex-1">
            {[products[2], products[3]].map((product) => (
              <div key={product.id} className="relative w-1/2 h-full">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover rounded-lg shadow-lg"
                />
                <div className="absolute bottom-4 left-4 text-white z-10">
                  <h3 className="text-sm font-semibold">{product.name}</h3>
                  <a
                    href="#"
                    className="text-white underline text-xs font-medium mt-1 inline-block"
                  >
                    Shop Now
                  </a>
                </div>
                <div className="absolute inset-0 bg-black/30 rounded-lg" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewArrival;
