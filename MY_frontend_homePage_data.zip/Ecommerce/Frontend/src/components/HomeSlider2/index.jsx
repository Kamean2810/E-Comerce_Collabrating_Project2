import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";

const categories = [
  { id: 1, name: "Android", icon: "📱", link: "/category/android" },
  { id: 2, name: "Laptops", icon: "💻", link: "/category/laptops" },
  { id: 3, name: "Headphones", icon: "🎧", link: "/category/headphones" },
  { id: 4, name: "Gaming", icon: "🎮", link: "/category/gaming" },
  { id: 5, name: "Watches", icon: "⌚", link: "/category/watches" },
  { id: 6, name: "Cameras", icon: "📷", link: "/category/cameras" },
  { id: 6, name: "Cameras", icon: "💃", link: "/category/women's fashion" },
];

const HomeSlider2 = () => {
  const scrollRef = useRef(null);
  const [selectedId, setSelectedId] = useState(null);

  const scroll = (direction) => {
    if (scrollRef.current) {
      const scrollAmount = direction === "left" ? -300 : 300;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  const handleClick = (id) => {
    setSelectedId(id);
  };

  return (
    <div className="py-10 bg-white border-t border-gray-300">
      <div className="container mx-auto px-4">
        {/* Title + Arrows */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-[40px] font-bold">Browse By Categories</h2>
          <div className="space-x-4">
            <button
              onClick={() => scroll("left")}
              className="w-12 h-12 text-2xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
            >
              &#8592;
            </button>
            <button
              onClick={() => scroll("right")}
              className="w-12 h-12 text-2xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
            >
              &#8594;
            </button>
          </div>
        </div>

        {/* Category Boxes */}
        <div
          ref={scrollRef}
          className="flex space-x-6 overflow-x-auto pb-4 scrollbar-hide"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
        >
          {categories.map((category) => (
            <Link
              to={category.link}
              key={category.id}
              onClick={() => handleClick(category.id)}
              className={`min-w-[180px] w-48 h-48 flex flex-col items-center justify-center text-center rounded-lg shadow-md cursor-pointer border-2 transition duration-300
                ${selectedId === category.id ? "bg-red-800 text-white border-red-800" : "bg-gray-100 hover:bg-red-100"}`}
            >
              <div className="text-5xl mb-4">{category.icon}</div>
              <div className="text-lg font-semibold">{category.name}</div>
            </Link>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-8">
          <button className="bg-black text-white px-6 py-3 rounded-full text-lg hover:bg-gray-800">
            View All Products
          </button>
        </div>

        <hr className="mt-10 border-t-2 border-gray-300" />
      </div>
    </div>
  );
};

export default HomeSlider2;
