import React, { useRef } from "react";

const products = [
  { id: 1, name: "The North Coat", price: "$491.99", image: "/item-21.jpg" },
  { id: 2, name: "Gucci Duffle Bag", price: "$899.99", image: "/item-22.jpg" },
  { id: 3, name: "RGB Liquid CPU Cooler", price: "$59.99", image: "/item-23.jpg" },
  { id: 4, name: "Small Book Self", price: "$39.99", image: "/item-24.jpg" },
  { id: 5, name: "Home Decuration Piece", price: "$12.99", image: "/item-25.jpg" },
  { id: 6, name: "MakeUp Box for Women's", price: "$81.99", image: "/item-26.jpg" },
  { id: 7, name: "Orignal Labubu Doll", price: "$85.99", image: "/item-27.jpg" },
  { id: 8, name: "Men's Office Shose", price: "$17.99", image: "/item-5.jpg" },
  { id: 9, name: "Men's Office Shose", price: "$17.99", image: "/item-8.jpg" },
  { id: 10, name: "Men's Office Shose", price: "$17.99", image: "/item-7.jpg" },
  { id: 11, name: "Men's Office Shose", price: "$17.99", image: "/item-4.jpg" },
  { id: 12, name: "Men's Office Shose", price: "$17.99", image: "/item-9.jpg" },
];

const HomeSlider4 = () => {
  const scrollRef = useRef(null);

  const scroll = (direction) => {
    if (scrollRef.current) {
      const scrollAmount = direction === "left" ? -1000 : 1000;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  return (
    <div className="py-10 bg-white">
      <div className="container mx-auto px-4">
        {/* Title + Arrows */}
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-[40px] md:text-[55px] font-bold">Explore Our Products</h2>
          <div className="space-x-4">
            <button
              onClick={() => scroll("left")}
              className="w-10 h-10 md:w-12 md:h-12 text-xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
            >
              &#8592;
            </button>
            <button
              onClick={() => scroll("right")}
              className="w-10 h-10 md:w-12 md:h-12 text-xl bg-gray-200 hover:bg-gray-300 rounded-full shadow"
            >
              &#8594;
            </button>
          </div>
        </div>

        {/* Scrollable 2-row Product Grid */}
        <div
          ref={scrollRef}
          className="overflow-x-auto pb-4 scrollbar-hide"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <div
            className="grid grid-rows-2 auto-cols-max grid-flow-col gap-6 px-1"
            style={{ minWidth: "max-content" }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="w-[220px] md:w-[240px] lg:w-[260px] bg-gray-100 rounded-lg shadow-md p-4 flex-shrink-0"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-contain rounded-md mb-4"
                />
                <h3 className="text-lg font-semibold">{product.name}</h3>
                <p className="text-red-500 font-bold text-xl">{product.price}</p>
              </div>
            ))}
          </div>
        </div>

        {/* View All Button */}
        <div className="flex justify-center mt-10">
          <button className="bg-black text-white px-6 py-3 rounded-full text-lg hover:bg-gray-800 transition">
            View All Products
          </button>
        </div>
      </div>
    </div>
  );
};

export default HomeSlider4;
