import React from "react";

const features = [
  {
    id: 1,
    title: "Free and Fast Delivery",
    icon: "🚚",
  },
  {
    id: 2,
    title: "24/7 Customer Service",
    icon: "🎧",
  },
  {
    id: 3,
    title: "Money Back Guarantee",
    icon: "✅",
  },
];

const PreFotter = () => {
  return (
    <div className="py-10 bg-white">
      <div className="container mx-auto px-4">
        {/* Feature Boxes */}
        <div className="flex flex-col md:flex-row justify-center items-center gap-40">
          {features.map((feature) => (
            <div
              key={feature.id}
              className="flex flex-col items-center text-center max-w-[200px]"
            >
              {/* Emoji Circle */}
              <div
                className={`w-20 h-20 rounded-full flex items-center justify-center text-3xl mb-6 text-white ${
                  feature.id === 3
                    ? "bg-gray-800 border-2 border-green-500"
                    : "bg-gray-800"
                }`}
              >
                {feature.icon}
              </div>

              {/* Text Below */}
              <div className="text-lg font-medium text-gray-800">
                {feature.title}
              </div>
            </div>
          ))}
        </div>

        {/* Removed <hr /> */}
      </div>
    </div>
  );
};

export default PreFotter;