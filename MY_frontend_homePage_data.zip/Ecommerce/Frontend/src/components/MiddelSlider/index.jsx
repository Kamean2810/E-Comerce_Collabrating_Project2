import React, { useState, useEffect } from "react";

const slides = [
  {
    id: 1,
    image: "/item-20.jpg",
    title: "HAVIT Game Pad",
    price: "$49.99",
    discount: "Save 20%",
  },
  {
    id: 2,
    image: "/item-20.jpg",
    title: "AK-900 Keyboard",
    price: "$89.99",
    discount: "Save 30%",
  },
  {
    id: 3,
    image: "/item-20.jpg",
    title: "Gaming Chair",
    price: "$129.99",
    discount: "Up to 40% Off",
  },
];

const MiddelSlider = () => {
  const [current, setCurrent] = useState(0);
  const total = slides.length;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % total);
    }, 5000);
    return () => clearInterval(interval);
  }, [total]);

  const next = () => setCurrent((prev) => (prev + 1) % total);
  const prev = () => setCurrent((prev) => (prev - 1 + total) % total);

  return (
    <div className="MiddleSlider relative w-full flex justify-center py-12">
      <div className="relative w-[95%] max-w-[1450px] h-[600px] overflow-hidden rounded-lg shadow-lg">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === current ? "opacity-100 z-10" : "opacity-0 z-0"
            }`}
          >
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover rounded-lg"
            />

            {/* Overlay content */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6 flex flex-col items-center">
              <h2 className="text-white text-xl font-semibold mb-2">{slide.title}</h2>
              <button className="bg-red-500 hover:bg-red-600 text-white px-5 py-2 rounded-full text-sm">
                View Product
              </button>
            </div>
          </div>
        ))}

        {/* Arrows */}
        <button
          onClick={prev}
          className="absolute top-1/2 left-4 transform -translate-y-1/2 z-20 bg-white bg-opacity-70 hover:bg-opacity-90 p-2 rounded-full shadow"
        >
          &#8592;
        </button>
        <button
          onClick={next}
          className="absolute top-1/2 right-4 transform -translate-y-1/2 z-20 bg-white bg-opacity-70 hover:bg-opacity-90 p-2 rounded-full shadow"
        >
          &#8594;
        </button>
      </div>
    </div>
  );
};

export default MiddelSlider;
