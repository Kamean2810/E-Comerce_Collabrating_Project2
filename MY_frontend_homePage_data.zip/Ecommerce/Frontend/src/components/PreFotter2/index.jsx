import React from "react";
import { FaPaperPlane } from "react-icons/fa";
import { Link } from "react-router-dom"; // Only if you're using React Router

const PreFooter2 = () => {
  return (
    <footer className="bg-black text-white py-20">
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
        {/* Column 1: Exclusive */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">Exclusive</h2>
          <p className="text-white">Subscribe</p>
          <p className="text-white">Get 10% off your first order</p>

          {/* Email Input + Send Icon */}
          <form className="flex items-center border border-gray-500 rounded overflow-hidden">
            <input
              type="email"
              placeholder="Enter your email"
              className="bg-black text-white px-4 py-3 outline-none w-full placeholder-gray-400"
            />
            <button type="submit" className="bg-white text-black px-4 py-3">
              <FaPaperPlane />
            </button>
          </form>
        </div>

        {/* Column 2: Support */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-2">Support</h3>
          <ul className="space-y-3 text-gray-400">
            <li>Mughalpura, Lahore, Pakistan</li>
            <li>
              <a href="mailto:exclusive@gmail.com" className="hover:text-white">
                exclusive@gmail.com
              </a>
            </li>
            <li>
              <a href="tel:+923020473116" className="hover:text-white">
                +92 302 0473116
              </a>
            </li>
          </ul>
        </div>

        {/* Column 3: Account */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-2">Account</h3>
          <ul className="space-y-3 text-gray-400">
            <li>
              <Link to="/account" className="hover:text-white">
                My Account
              </Link>
            </li>
            <li>
              <Link to="/login" className="hover:text-white">
                Login / Register
              </Link>
            </li>
            <li>
              <Link to="/cart" className="hover:text-white">
                Cart
              </Link>
            </li>
          </ul>
        </div>

        {/* Column 4: Quick Links */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-2">Quick Links</h3>
          <ul className="space-y-3 text-gray-400">
            <li>
              <Link to="/privacy-policy" className="hover:text-white">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms-of-use" className="hover:text-white">
                Terms of Use
              </Link>
            </li>
            <li>
              <Link to="/faq" className="hover:text-white">
                FAQ
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-white">
                Contact
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default PreFooter2;
