import React from "react";

const AboutUs = () => {
  return (
    <div className="bg-gray-50 text-gray-800 min-h-screen pt-10 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Title */}
        <h1 className="text-4xl font-bold text-center mb-8">About Us</h1>

        {/* Hero Section */}
        <div className="flex flex-col md:flex-row items-center gap-10 mb-12">
          <img
            src="https://images.unsplash.com/photo-1542831371-d531d36971e6"
            alt="About Us"
            className="w-full md:w-1/2 rounded-lg shadow-lg"
          />
          <div className="md:w-1/2">
            <h2 className="text-2xl font-semibold mb-4">Welcome to Exclusive</h2>
            <p className="text-lg leading-relaxed">
              At <span className="font-bold text-black">Exclusive</span>, we're more than just a store — we're a lifestyle.
              We aim to bring high-quality fashion and unbeatable value to people all over the world.
              Whether you're looking for the latest trends or timeless classics, we have it all.
            </p>
          </div>
        </div>

        {/* Mission / Vision / Values */}
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
            <h3 className="text-xl font-semibold mb-2">🚀 Our Mission</h3>
            <p>
              To provide top-quality products at affordable prices, while delivering exceptional customer service.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
            <h3 className="text-xl font-semibold mb-2">🌍 Our Vision</h3>
            <p>
              To become a global leader in the eCommerce space, inspiring people to shop smart and live well.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition">
            <h3 className="text-xl font-semibold mb-2">💡 Our Values</h3>
            <p>
              Integrity, Innovation, Customer Satisfaction, and Commitment to Excellence.
            </p>
          </div>
        </div>

        {/* Team / CTA */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-semibold mb-4">Meet the Team Behind the Brand</h2>
          <p className="max-w-3xl mx-auto text-lg text-gray-700">
            We’re a team of passionate designers, developers, and marketers building something we believe in.
            We're proud to serve our customers and help shape the future of online shopping.
          </p>
        </div>

        {/* CTA Footer */}
        <div className="mt-16 bg-black text-white py-10 rounded-lg text-center">
          <h3 className="text-2xl font-semibold mb-2">Ready to explore?</h3>
          <p className="mb-4">Start shopping with us today and experience the difference.</p>
          <a
            href="/"
            className="inline-block bg-white text-black px-6 py-2 font-semibold rounded hover:bg-gray-100 transition"
          >
            Go to Home
          </a>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
