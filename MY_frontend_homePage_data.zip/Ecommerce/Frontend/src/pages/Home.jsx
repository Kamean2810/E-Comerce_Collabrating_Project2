import React from "react";
import Header from "../components/Header";
import HomeSlider from "../components/HomeSlider";
import HomeSlider2 from "../components/HomeSlider2";
import HomeSlider3 from "../components/HomeSlider3";
import MiddelSlider from "../components/MiddelSlider";
import HomeSlider4 from "../components/HomeSlider4";
import NewAriivel from "../components/NewAriivel";
import PreFotter from "../components/PreFotter";
import PreFotter2 from "../components/PreFotter2";


const Home = () => {
  return (
    <>
      <Header />
      <HomeSlider />
      <HomeSlider2 />
      <HomeSlider3 />
      <MiddelSlider />
      <HomeSlider4 />
      <NewAriivel />
      <PreFotter />
      <PreFotter2 />
    </>
  );
};

export default Home;
